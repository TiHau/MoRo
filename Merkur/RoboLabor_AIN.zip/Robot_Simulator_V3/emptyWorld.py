from Robot_Simulator_V3 import World

def buildWorld():
    world = World.World(20, 20)
    return world