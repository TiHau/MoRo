Oliver Bittel
Fakultät Informatik
25.09.2019

Verzeichnis enthält verschiedene Python 3.5 Pakete:

* Robot_Simulator_V3:
  Simulator für mobilen Roboter

* PoseEstimator:
  Koppelnavigation und Kalman-Filter für Lokalisierung.
  Plot utilities.

* NumPy+MatPlotLibDemos

* PraktikumsAufgabe1
  (leer)

* PraktikumsAufgabe2
  (leer)

* PraktikumsAufgabe3
  (leer)

  PraktikumsAufgabe4
  (leer)

* PraktikumsAufgabe5
  (leer)

* PraktikumsAufgabe6
  (leer)



